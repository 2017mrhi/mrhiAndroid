package com.mrhi2020.ex65servicebindtest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    //MusicService 참조변수
    MusicService musicService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //이 액티비티가 화면에 보여질 때 MusiceServie 객체와 연결작업 수행
    @Override
    protected void onResume() {
        super.onResume();

        if(musicService==null){
            //MusicService 를 실행하고 연결하기!!!

        }
    }

    public void clickStart(View view) {
        if(musicService != null) musicService.startMusic();
    }

    public void clickPause(View view) {
        if(musicService !=null) musicService.pauseMusic();
    }

    public void clickStop(View view) {
        if(musicService != null) {
            musicService.stopMusic();
        }
    }
}